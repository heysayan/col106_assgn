import java.util.ArrayList;

import Includes.*;
public class test{
    public static void main(String args[]){
FrequencyAnalysis a = new FrequencyAnalysis();
try{
a.fillDictionaries("Turbine performance utilities require performance enhancements due to the rapid and unforgiving increase in energy demands calling upon engineers to design and develop energy efficient techniques to optimize power output for energy producing utilities. Among the most reliable technologies for enhancing gas turbine performance in hot and humid climates is the technique of cooling the inlet air using techniques such as fogging and evaporative cooling as discussed in this report. It is clearly a technical and performance advantage to cool air at the inlet leading to the modification of the density of air at the inlet with the aggregate effect of improving the performance of a turbine or power generation utility. That is in consideration of the fact that temperature rises during summer in hot climate regions impair the performance of a power generating utility by reducing the density of air at the intake. One characteristic influencing factor as to the choice of cooling technique to adopt is the ambient ratio of the humidity of air and the density as critical factors. Among the technique is the fogging technique and evaporative cooling as discussed in this paper. Our experts can deliver a customized essay tailored to your instructions for only $. $./page  qualified specialists online Learn more Inlet Air Cooling Systems in Hot and Humid Climates Gas Turbine Fogging An extensive application of the fogging technique particularly in power generation utilities leads to the optimization of power production with a rapid payback particularly when using the fogging technique at the inlet of a gas turbine. The impact on the performance of a fogged inlet turbine is influenced by a number of performance determining parameters. Holman () and Johnson () concur that these parameters include the temperature at the inlet of a turbine, the mechanical efficiency of a gas generator, the optimum speed that can be attained by the gas turbine, the temperature of exhaust gases, and the pressure at which the turbine compressor discharges gas in relation to the rate at which fogging is applied at the inlet of the gas turbine. Further arguments by the Technical specification of the project, design, manufacturing, and installation of media evaporative cooling system for  units of Fars combined cycle power plant () report indicates that gas turbine fogging draws on the use of demineralized water with the objective to reduce the applied water into minute droplets using specially engineered nozzles for the purpose of producing atomized water droplet sprays at very high pressures. The technique is aimed at producing fog at the inlet of a turbine during the evaporation process with the consequent objective of cooling the air at the inlet as illustrated below (Cortes, & Willems, ). By Zadpoor and Golshan,  It has been demonstrated that the cooling efficiency due to fogging at the inlet of a turbine is close or at least almost one hundred percent effective. However, the resulting cooling efficiency is also influenced by the design constraints of the inlet of a turbine and other design variables such as the typical design of the compressor aimed at achieving efficient wet-bulb temperature values. Johnson () provides an overview of a typical high pressure gas turbine (Chaker, Meher-Homji, Mee, ). Johnson ()s argument is based on a typical fogging system design that consist of high pressure pumping compartments organized sequentially to provide high pressure water to several nozzles designed to provide excellent fogging effects on the high pressure water from the array of high pressure reciprocating pumps. As an engineering requirement, high pressure plays the critical role of forcing the demineralized water into droplets through the application of very high pressures on the atomizing nozzles. In response to the high pressure water, the fogging effect results from the creation of a large number of droplets whose physical characteristics are influenced by a number of parameters such as the pumping pressure, the number of nozzles in the arrangement of nozzles, and the orientation of the turbine itself to the nozzles (Technical specification of the project, design, manufacturing, and installation of media evaporative cooling system for  units of Fars combined cycle power plant, ) and (Brooks, n.d). Bradury, Hancock and Lewis () demonstrate the fact that in a typical fogging environment, large gas turbines show the need to be equipped with a large number of nozzles with the overall effect of creating a fogging effect equivalent to the fogging demands on the turbine inlet to optimize the density of the inlet air. Moreover, the use of demineralized water is critical to avoid the possibility of fouling compressor blades and the aggregate corrosion effect of mineral water and high temperature gases on a turbines construction materials. A typical example of a gas turbine is illustrated below (Grabe & Chappell, ). The above diagram demonstrates a practical application of the fogging effect in the respective engineering fields of application. It can be clearly discerned in the diagram that the turbine is a two shaft design with the effect of applying the fogging technique at the inlet to improve its performance (Brooks, n.d). Typically, the turbine is largely used in gas or oil industries. In addition to that, it provides a basis for further studies on the application and enhancement of turbine performance using the fogging effect on the inlet gases in the discussion, as an industry application (Grabe & Chappell, ). On-Time Delivery!Get your % customized paper done in as little as  hours Let`s start Analytically, it is worth noting that the performance of a two shaft turbine is strongly correlated with the compressor and the respective turbine efficiency. The correlating or matching variables are defined by the gaseous flow in the turbine, the temperature of the flow and pressures that can be achieved in the turbine. That also relates to the equilibrium conditions that are attained between the compressor and the turbine. Other influencing variables include work output, the degree of compatibility of the flow, and optimum speeds achieved by the rotating turbine and the compressor (Boonnasa, Muangnapoh & Namprakai, ). The speed of the rotating turbine and the compressor in all types of engines such as a multiple spool and free spool engines must be in equilibrium for efficiency to be attained. Besides that, the flow of gas in a turbine is continuous hence the demand for compatibility in the flow. There is also need to establish an equilibrium condition between power outputs from the compressor and the input torque from the driver shaft. A typical example of the arrangement is illustrated in the above diagram. Different turbine designs used in different environments demand varying conditions and equilibriums conditions. In addition to that, an overall critical factor in the performance of these varied models is the relationship between the ambient temperature and the maximum speed that can be attained at optimum working conditions. However, some turbines and engines are designed based on ISO standards. In that case, the ambient temperature is a function of the optimum rotational speed that can be attained by the turbine. As the ambient temperature rises, the driver turbines power experiences a decrease. However, the driver turbine efficiency curve can be improved by orienting the geometry of the turbine to optimize power outputs in relation to the effects of the ambient temperature. Therefore the overall effect of the ambient temperature on the performance of a turbine is worth discussing here (Arrieta & Lora, n.d). The Effect of the ambient Temperature It has been demonstrated that the ambient temperature attained by a gas has a mathematically inverse relationship with the inflow rate and the drop in temperature of the inlet gas. Arrieta and Lora (n.d) note that the drop in temperature has the effect of increasing the density of the flow with the ultimate effect on the volume of the flow and power output. From a practical perspective, lower temperatures causes an increase in mass flow infl... truncated due to excessive output!");
}
catch(Exception e){}
System.out.println("Printing the noOfcollisions:");
for (int i : a.noOfCollisions()){
    System.out.println(i);
}

System.out.println("Printing the hexadecimal sign:");
for (String i : a.hashTableHexaDecimalSignature()){
    System.out.println(i);
    System.out.println("Hexstring length :");
    System.out.println(i.length());
}
System.out.println("Printing the distinct words:");
String[] p1=a.distinctWords();
for (String i : p1){
    System.out.print(i+" ,");
}
System.out.println("\nPrinting the distinct words count:");
Integer[] p2 = a.distinctWordsFrequencies();
for (Integer i : p2){
    System.out.print(i.toString()+" ,");
}
System.out.println("\nNumber of distinct words: ");
System.out.println(p1.length);
System.out.println("\nNumber of distinct words count: ");
System.out.println(p2.length);
}}
/*
for (int i = 0;i<dict2.hashTable.length;i++){
    if (dict2.hashTable[i]!=null){
        if (dict2.hashTable[i].size()>0){
            b+= Math.pow(2,dict2.hashTable.length-1-i);
        }
    }
}
for (int i = 0;i<dict3.hashTable.length;i++){
    if (dict3.hashTable[i]!=null){
        if (dict3.hashTable[i].size()>0){
            c+= Math.pow(2,dict3.hashTable.length-1-i);
        }
    }
}*/